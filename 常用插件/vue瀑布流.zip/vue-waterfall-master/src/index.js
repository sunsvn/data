import Waterfall from './waterfall'
import WaterfallSlot from './waterfall-slot'

module.exports = {
  Waterfall: Waterfall,
  WaterfallSlot: WaterfallSlot,
  waterfall: Waterfall,
  waterfallSlot: WaterfallSlot
}
