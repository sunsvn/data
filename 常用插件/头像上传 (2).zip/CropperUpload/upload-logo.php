<?php
	$arr = array("status"=>"1");
	echo json_encode($arr);
?>